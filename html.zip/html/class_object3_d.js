var class_object3_d =
[
    [ "Object3D", "class_object3_d.html#a4ca68251d3517e68714370315b494e52", null ],
    [ "applyTransformations", "class_object3_d.html#aca9f112757bdb65e01bb02bdcdb26b16", null ],
    [ "draw", "class_object3_d.html#a9a55d105f9dc340559f6df7e9587eda6", null ],
    [ "posZ", "class_object3_d.html#ad74a0647ebf9ef373a4a989905ce4a37", null ],
    [ "rotZ", "class_object3_d.html#a32d3afb2179d19ca980f7b7c1c45cbba", null ],
    [ "scaleZ", "class_object3_d.html#a7b86b6ffe741d89e23d8bcad71883279", null ],
    [ "textureId", "class_object3_d.html#a3599c3445b9863cc58041099286e2bea", null ]
];