var searchData=
[
  ['jump_0',['jump',['../class_player.html#a70e21ca98281b7d72f105f2693113d7e',1,'Player']]],
  ['jump_5fforce_1',['JUMP_FORCE',['../class_player.html#a2ce78de0f776e7ebebc5078cd94f1c96',1,'Player']]]
];
