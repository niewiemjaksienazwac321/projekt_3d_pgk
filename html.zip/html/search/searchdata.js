var indexSectionsWithContent =
{
  0: "abcdefghijlmoprstuvy",
  1: "bcefgopst",
  2: "bcegmp",
  3: "acdehijlmoprsu",
  4: "dgijprstuvy",
  5: "pr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

