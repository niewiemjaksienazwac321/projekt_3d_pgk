var searchData=
[
  ['instance_0',['instance',['../class_engine.html#a51493b63c58390f775dd2bc6f72a2b75',1,'Engine']]],
  ['isgrounded_1',['isGrounded',['../class_player.html#abfaf051423024af360196f738e2a2250',1,'Player']]]
];
