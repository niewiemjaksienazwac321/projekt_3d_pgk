var searchData=
[
  ['gravity_0',['GRAVITY',['../class_player.html#a1488b7f6ac646c83fbc90ef4b0f6ab2f',1,'Player']]]
];
