var searchData=
[
  ['jump_5fforce_0',['JUMP_FORCE',['../class_player.html#a2ce78de0f776e7ebebc5078cd94f1c96',1,'Player']]]
];
