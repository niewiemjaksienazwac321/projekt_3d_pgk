var searchData=
[
  ['init_0',['init',['../class_engine.html#a20c5957324e3a0dea55f898b42f817d8',1,'Engine']]],
  ['instance_1',['instance',['../class_engine.html#a51493b63c58390f775dd2bc6f72a2b75',1,'Engine']]],
  ['isgrounded_2',['isGrounded',['../class_player.html#abfaf051423024af360196f738e2a2250',1,'Player']]]
];
