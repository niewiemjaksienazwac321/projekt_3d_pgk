var class_pyramid_object =
[
    [ "draw", "class_pyramid_object.html#a00f1af23659c3646f4164c73fa572f56", null ]
];