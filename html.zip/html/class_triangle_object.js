var class_triangle_object =
[
    [ "draw", "class_triangle_object.html#a12712edfccd8531c6cbded53cfef9a86", null ]
];