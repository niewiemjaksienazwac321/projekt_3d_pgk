var class_player =
[
    [ "draw", "class_player.html#aa617c99ad057263ba54541294b203a14", null ],
    [ "jump", "class_player.html#a70e21ca98281b7d72f105f2693113d7e", null ],
    [ "setTextures", "class_player.html#a97f0dc38f90f249d773c76e74bac8ef9", null ],
    [ "updatePhysics", "class_player.html#a4f1b68a8f353245b9080e0540a8f431e", null ],
    [ "GRAVITY", "class_player.html#a1488b7f6ac646c83fbc90ef4b0f6ab2f", null ],
    [ "isGrounded", "class_player.html#abfaf051423024af360196f738e2a2250", null ],
    [ "JUMP_FORCE", "class_player.html#a2ce78de0f776e7ebebc5078cd94f1c96", null ],
    [ "texBack", "class_player.html#aef534eaf8130c4fbf24f063ba6ad4cb7", null ],
    [ "texFront", "class_player.html#ab8a9debbb4ea474c0c4b808f23607ae6", null ],
    [ "texLeft", "class_player.html#a2b908e2947c5d771c5921ff116268c49", null ],
    [ "texRight", "class_player.html#adc3f3e6e50a979da58e265bb9260493b", null ],
    [ "texTop", "class_player.html#af8a9b2fd26c42f7539b34a7445a9c383", null ],
    [ "velocityY", "class_player.html#a2d575a35135f4c4c2fd89f01751c4462", null ]
];