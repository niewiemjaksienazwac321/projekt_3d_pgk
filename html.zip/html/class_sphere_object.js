var class_sphere_object =
[
    [ "draw", "class_sphere_object.html#a9781c0fbcc6eca0e466df8bdb12d0a12", null ]
];